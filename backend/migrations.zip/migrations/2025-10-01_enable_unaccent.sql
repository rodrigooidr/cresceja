-- Habilita extensões usadas por buscas acentuadas/semelhantes
CREATE EXTENSION IF NOT EXISTS unaccent;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
