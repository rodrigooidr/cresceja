import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { randomUUID } from 'crypto';

export const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads');
await fsp.mkdir(UPLOAD_DIR, { recursive: true });

export async function saveBuffer(buffer, originalName = 'file.bin') {
  const ext = path.extname(originalName) || '';
  const name = `${Date.now()}-${randomUUID()}${ext}`;
  const full = path.join(UPLOAD_DIR, name);
  await fsp.writeFile(full, buffer);
  return { fileName: name, path: full, url: `/uploads/${name}` };
}

export async function saveStream(readable, originalName = 'file.bin') {
  const ext = path.extname(originalName) || '';
  const name = `${Date.now()}-${randomUUID()}${ext}`;
  const full = path.join(UPLOAD_DIR, name);
  await new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(full);
    readable.pipe(ws);
    ws.on('finish', resolve);
    ws.on('error', reject);
  });
  return { fileName: name, path: full, url: `/uploads/${name}` };
}

export default { UPLOAD_DIR, saveBuffer, saveStream };