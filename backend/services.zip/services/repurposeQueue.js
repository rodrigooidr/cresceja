
import { Queue, QueueEvents } from 'bullmq';
import { getRedis } from '../config/redis.js';
const connection = getRedis();
const queue = new Queue('repurpose', { connection });
const events = new QueueEvents('repurpose', { connection });
async function enqueueRepurpose(postId, modes){
  return await queue.add('repurpose', { postId, modes }, { removeOnComplete: 100, removeOnFail: 100, attempts: 2, backoff: { type: 'exponential', delay: 2000 } });
}
export default { queue, events, enqueueRepurpose };
