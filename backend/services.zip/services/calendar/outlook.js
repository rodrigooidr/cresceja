// backend/services/calendar/outlook.js
import msal from '@azure/msal-node';
import { query } from '../../config/db-client.js';

const tenant = process.env.AZURE_TENANT_ID;
const config = {
  auth: {
    clientId: process.env.AZURE_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${tenant}`,
    clientSecret: process.env.AZURE_CLIENT_SECRET,
  },
};

const msalClientApp = new msal.ConfidentialClientApplication(config);

export async function saveTokens(userId, tokens) {
  await query(
    `INSERT INTO calendar_integrations (user_id, provider, tokens)
     VALUES ($1,'outlook',$2::jsonb)
     ON CONFLICT (user_id, provider)
     DO UPDATE SET tokens=$2::jsonb, updated_at=NOW()`,
    [userId, JSON.stringify(tokens)]
  );
}

export async function getTokens(userId) {
  const r = await query(
    "SELECT tokens FROM calendar_integrations WHERE user_id=$1 AND provider='outlook'",
    [userId]
  );
  const t = r.rows[0]?.tokens ?? null;
  return (t && typeof t === 'string') ? JSON.parse(t) : t;
}

export function getAuthUrl(state) {
  const params = new URLSearchParams({
    client_id: process.env.AZURE_CLIENT_ID,
    response_type: 'code',
    redirect_uri: process.env.AZURE_REDIRECT_URI,
    response_mode: 'query',
    scope: 'offline_access Calendars.ReadWrite User.Read',
    state,
  });
  return `https://login.microsoftonline.com/${tenant}/oauth2/v2.0/authorize?${params.toString()}`;
}

export async function handleCallback(code, userId) {
  const tokenRequest = {
    code,
    scopes: ['offline_access', 'Calendars.ReadWrite', 'User.Read'],
    redirectUri: process.env.AZURE_REDIRECT_URI,
  };
  const result = await msalClientApp.acquireTokenByCode(tokenRequest);

  // Guarda o essencial; MSAL mantém o cache em memória para acquires futuros.
  await saveTokens(userId, {
    accessToken: result.accessToken,
    expiresOn: result.expiresOn,  // Date
    account: result.account,      // { homeAccountId, username, ... }
    scope: 'Calendars.ReadWrite offline_access User.Read',
  });

  return { ok: true };
}

export async function createEvent(userId, { subject, start, end }) {
  const tokens = await getTokens(userId);
  if (!tokens?.accessToken) return { ok: false, error: 'not_connected' };

  const accessToken = tokens.accessToken;
  const startISO = new Date(start).toISOString();
  const endISO = new Date(end).toISOString();

  // checar conflito (getSchedule)
  const resFb = await fetch('https://graph.microsoft.com/v1.0/me/calendar/getSchedule', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      // 'Prefer': 'outlook.timezone="UTC"', // opcional
    },
    body: JSON.stringify({
      schedules: ['me'],
      startTime: { dateTime: startISO, timeZone: 'UTC' },
      endTime:   { dateTime: endISO,   timeZone: 'UTC' },
      availabilityViewInterval: 30,
    }),
  });

  const fb = await resFb.json().catch(() => ({}));
  const busy = fb?.value?.[0]?.scheduleItems || [];
  if (busy.length) return { ok: false, error: 'conflict', busy };

  // criar evento
  const res = await fetch('https://graph.microsoft.com/v1.0/me/events', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      subject,
      start: { dateTime: startISO, timeZone: 'UTC' },
      end:   { dateTime: endISO,   timeZone: 'UTC' },
    }),
  });

  if (!res.ok) {
    const details = await res.text().catch(() => '');
    return { ok: false, error: 'create_failed', details };
  }
  return { ok: true };
}

export default { getAuthUrl, handleCallback, createEvent, getTokens, saveTokens };