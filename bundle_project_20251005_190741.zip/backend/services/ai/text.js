export async function generateSuggestion({ prompt = '' } = {}) {
  // Simple stub returning placeholder copy
  return {
    headline: 'Placeholder headline',
    caption: 'Placeholder caption',
    hashtags: [],
    cta: null,
    variants: []
  };
}
