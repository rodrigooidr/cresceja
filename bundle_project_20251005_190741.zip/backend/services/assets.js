export async function uploadToAssets(req) {
  return { id: '00000000-0000-0000-0000-000000000000' };
}
