-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =========================
-- 1) Tenancy básico
-- =========================
CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NULL REFERENCES companies(id) ON DELETE SET NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'operator', -- admin|marketing|sales|operator
  is_owner BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMP NULL
);

-- =========================
-- 2) Leads / CRM
-- =========================
CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NULL REFERENCES companies(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  email TEXT NULL,
  phone TEXT NULL,
  status TEXT NOT NULL DEFAULT 'novo',      -- novo|qualificado|cliente|perdido
  source_channel TEXT NULL,                 -- whatsapp|instagram|facebook|landing|import_csv|...
  consent BOOLEAN NOT NULL DEFAULT FALSE,   -- LGPD consent
  score INTEGER NOT NULL DEFAULT 0,
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  erased_at TIMESTAMP NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_leads_email ON leads(email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_leads_phone ON leads(phone) WHERE phone IS NOT NULL;

CREATE TABLE IF NOT EXISTS channel_id_map (
  lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  channel_type TEXT NOT NULL,
  external_id TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  PRIMARY KEY (channel_type, external_id)
);

CREATE TABLE IF NOT EXISTS crm_opportunities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT 'Oportunidade',
  value NUMERIC(14,2) NULL,
  stage TEXT NOT NULL DEFAULT 'novo',   -- novo|qualificando|proposta|ganho|perdido
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_crm_opps_lead ON crm_opportunities(lead_id);

-- =========================
-- 3) Conversas e Mensagens
-- =========================
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  channel_type TEXT NOT NULL,                 -- whatsapp|instagram|facebook
  status TEXT NOT NULL DEFAULT 'open',        -- open|closed
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  direction TEXT NOT NULL,                    -- inbound|outbound
  type TEXT NOT NULL DEFAULT 'text',          -- text|image|audio|video|file|location|button
  text TEXT NULL,
  attachments JSONB NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_messages_lead ON messages(lead_id);
CREATE INDEX IF NOT EXISTS idx_conv_lead ON conversations(lead_id);

-- =========================
-- 4) Agenda (compromissos)
-- =========================
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NULL REFERENCES leads(id) ON DELETE SET NULL,
  user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  title TEXT NOT NULL DEFAULT 'Atendimento',
  start_at TIMESTAMP NOT NULL,
  end_at TIMESTAMP NOT NULL,
  channel_type TEXT NULL,
  status TEXT NOT NULL DEFAULT 'pendente', -- pendente|confirmado|cancelado|reagendado
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_appointments_start ON appointments(start_at);

CREATE TABLE IF NOT EXISTS calendar_integrations (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,                    -- google|outlook
  tokens JSONB NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, provider)
);

-- =========================
-- 5) Marketing / Posts / Repurpose
-- =========================
CREATE TABLE IF NOT EXISTS social_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NULL REFERENCES companies(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  media_url TEXT NULL,
  channel TEXT NOT NULL,          -- instagram|facebook|linkedin|instagram_story|email_marketing|reels_tiktok
  scheduled_at TIMESTAMP NULL,
  status TEXT NOT NULL DEFAULT 'rascunho', -- rascunho|pendente|aprovado|publicado|erro
  created_by UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  approved_level INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS repurpose_jobs (
  post_id UUID PRIMARY KEY REFERENCES social_posts(id) ON DELETE CASCADE,
  status TEXT NOT NULL, -- queued|completed|failed
  result JSONB NOT NULL DEFAULT '{}'::jsonb,
  finished_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- =========================
-- 6) Anexos e Transcrição
-- =========================
CREATE TABLE IF NOT EXISTS attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  company_id UUID NULL REFERENCES companies(id) ON DELETE SET NULL,
  url TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'generic', -- generic|audio|image|video|document
  mime_type TEXT NULL,
  size INTEGER NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- =========================
-- 7) Segmentação
-- =========================
CREATE TABLE IF NOT EXISTS segments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NULL REFERENCES companies(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  filter JSONB NOT NULL, -- { min_score: 60, channel:'whatsapp' ... }
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- =========================
-- 8) Uso de IA / Custos
-- =========================
CREATE TABLE IF NOT EXISTS ai_credit_usage (
  user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  category TEXT NOT NULL, -- attend|content|transcription
  period_start TIMESTAMP NOT NULL,
  period_end TIMESTAMP NOT NULL,
  used INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, category, period_start)
);

CREATE TABLE IF NOT EXISTS ai_usage_logs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  service TEXT NOT NULL, -- attend|content|transcription
  tokens INT NOT NULL DEFAULT 0,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_created ON ai_usage_logs(created_at);

-- =========================
-- 9) LGPD / Governança
-- =========================
CREATE TABLE IF NOT EXISTS lgpd_consents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  consent BOOLEAN NOT NULL,
  purpose TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lgpd_erasure_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,             -- ex: message.send, post.approve
  target_type TEXT NULL,            -- lead|message|post|user|...
  target_id UUID NULL,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at);

-- =========================
-- 10) WhatsApp Templates
-- =========================
CREATE TABLE IF NOT EXISTS whatsapp_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  language TEXT NOT NULL DEFAULT 'pt_BR',
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- =========================
-- 11) Seeds úteis (opcionais)
-- =========================
INSERT INTO companies (id, name, plan)
SELECT '00000000-0000-0000-0000-000000000001', 'CresceJá Demo', 'pro'
WHERE NOT EXISTS (SELECT 1 FROM companies WHERE id='00000000-0000-0000-0000-000000000001');

INSERT INTO users (id, company_id, email, name, role, is_owner)
SELECT '11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-000000000001',
       'owner@cresceja.local', 'Owner', 'admin', TRUE
WHERE NOT EXISTS (SELECT 1 FROM users WHERE id='11111111-1111-1111-1111-111111111111');

-- =========================
-- 12) Billing (planos e clientes)
-- =========================
CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  monthly_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'BRL',
  modules JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_published BOOLEAN NOT NULL DEFAULT false,
  sort_order INT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NULL, -- vincule ao seu users.id
  company_name TEXT NULL,
  email TEXT NULL,
  active BOOLEAN NOT NULL DEFAULT false,
  start_date DATE NULL,
  end_date DATE NULL,
  plan_id TEXT NULL REFERENCES plans(id) ON UPDATE CASCADE ON DELETE SET NULL,
  modules JSONB NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

INSERT INTO plans (id, name, monthly_price, currency, modules, is_published)
VALUES
 ('starter','Starter',79,'BRL','{
    "omnichannel":{"enabled":true,"chat_sessions":200},
    "crm":{"enabled":true,"opportunities":500},
    "marketing":{"enabled":true,"posts_per_month":20},
    "approvals":{"enabled":true},
    "ai_credits":{"enabled":true,"credits":10000},
    "governance":{"enabled":true}
 }'::jsonb,false),
 ('pro','Pro',199,'BRL','{
    "omnichannel":{"enabled":true,"chat_sessions":1000},
    "crm":{"enabled":true,"opportunities":5000},
    "marketing":{"enabled":true,"posts_per_month":80},
    "approvals":{"enabled":true},
    "ai_credits":{"enabled":true,"credits":50000},
    "governance":{"enabled":true}
 }'::jsonb,false),
 ('business','Business',399,'BRL','{
    "omnichannel":{"enabled":true,"chat_sessions":5000},
    "crm":{"enabled":true,"opportunities":30000},
    "marketing":{"enabled":true,"posts_per_month":300},
    "approvals":{"enabled":true},
    "ai_credits":{"enabled":true,"credits":200000},
    "governance":{"enabled":true}
 }'::jsonb,false)
ON CONFLICT (id) DO UPDATE
SET name=EXCLUDED.name,
    monthly_price=EXCLUDED.monthly_price,
    currency=EXCLUDED.currency,
    modules=EXCLUDED.modules;

-- =========================
-- 13) Ajustes de planos e contadores de uso
-- =========================
ALTER TABLE plans
  ADD COLUMN IF NOT EXISTS is_free boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS trial_days integer DEFAULT 14,              -- dias do free
  ADD COLUMN IF NOT EXISTS billing_period_months integer DEFAULT 1;    -- meses do ciclo pago

CREATE INDEX IF NOT EXISTS idx_clients_active_dates
  ON clients(active, start_date, end_date);

CREATE TABLE IF NOT EXISTS usage_counters (
  id bigserial PRIMARY KEY,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  module_key text NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  used bigint NOT NULL DEFAULT 0,
  quota bigint,
  UNIQUE (client_id, module_key, period_start, period_end)
);

INSERT INTO plans (id, name, monthly_price, currency, modules, is_published, sort_order, is_free, trial_days, billing_period_months)
VALUES (
  'free',
  'Free',
  0,
  'BRL',
  '{
     "omnichannel": {"enabled": true,  "chat_sessions": 50},
     "crm":         {"enabled": true,  "opportunities": 50},
     "marketing":   {"enabled": false, "posts_per_month": 0},
     "approvals":   {"enabled": false},
     "ai_credits":  {"enabled": true,  "credits": 2000},
     "governance":  {"enabled": true}
   }'::jsonb,
  true,
  0,
  true,
  14,
  0
)
ON CONFLICT (id) DO UPDATE SET
  name='Free',
  monthly_price=0,
  currency='BRL',
  modules=EXCLUDED.modules,
  is_published=true,
  sort_order=0,
  is_free=true,
  trial_days=EXCLUDED.trial_days,
  billing_period_months=0;

CREATE TABLE IF NOT EXISTS leads (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  email TEXT,
  telefone TEXT NOT NULL,
  origem TEXT,
  status TEXT NOT NULL DEFAULT 'novo',
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

ALTER TABLE leads ADD COLUMN IF NOT EXISTS score INTEGER DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT '{}';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS responsavel TEXT;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS opportunities (
  id SERIAL PRIMARY KEY,                             -- pode manter INTEGER aqui, sem problema
  lead_id UUID REFERENCES leads(id) ON DELETE SET NULL,
  cliente TEXT NOT NULL,
  valor_estimado NUMERIC(12,2) DEFAULT 0,
  responsavel TEXT,
  status TEXT NOT NULL DEFAULT 'prospeccao',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_opportunities_status ON opportunities(status);
CREATE INDEX IF NOT EXISTS idx_opportunities_lead_id ON opportunities(lead_id);

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_opportunities_set_updated_at ON opportunities;

CREATE TRIGGER trg_opportunities_set_updated_at
BEFORE UPDATE ON opportunities
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS clients (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  email TEXT,
  telefone TEXT,
  contrato_url TEXT,
  status TEXT NOT NULL DEFAULT 'ativo',
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE EXTENSION IF NOT EXISTS pgcrypto; -- caso use UUID em outras tabelas

CREATE TABLE IF NOT EXISTS onboarding_tasks (
  id SERIAL PRIMARY KEY,
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  contrato BOOLEAN DEFAULT FALSE,
  assinatura BOOLEAN DEFAULT FALSE,
  nota_fiscal BOOLEAN DEFAULT FALSE,
  treinamento BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_onboarding_tasks_client_id ON onboarding_tasks(client_id);
);

CREATE TABLE IF NOT EXISTS conversations (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients(id) ON DELETE SET NULL,
  canal TEXT NOT NULL DEFAULT 'whatsapp',
  status TEXT NOT NULL DEFAULT 'pendente', -- pendente, em_andamento, resolvido
  assigned_to TEXT, -- email do atendente
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  conversation_id INTEGER REFERENCES conversations(id) ON DELETE CASCADE,
  sender TEXT NOT NULL, -- 'cliente' | 'agente' | 'sistema'
  content TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);


-- NPS Surveys (liga em clients.id -> UUID)
CREATE TABLE IF NOT EXISTS nps_surveys (
  id SERIAL PRIMARY KEY,
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  sent_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_nps_surveys_client_id ON nps_surveys(client_id);

-- NPS Responses (liga em nps_surveys.id -> INTEGER/SERIAL)
CREATE TABLE IF NOT EXISTS nps_responses (
  id SERIAL PRIMARY KEY,
  survey_id INTEGER REFERENCES nps_surveys(id) ON DELETE CASCADE,
  score INTEGER NOT NULL CHECK (score BETWEEN 0 AND 10),
  comment TEXT,
  responded_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_nps_responses_survey_id ON nps_responses(survey_id);

-- Rewards (liga em clients.id -> UUID)
CREATE TABLE IF NOT EXISTS rewards (
  id SERIAL PRIMARY KEY,
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  type TEXT NOT NULL, -- cupom/bonus/upgrade
  value TEXT,
  expires_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_rewards_client_id ON rewards(client_id);



CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  user_email TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id INTEGER,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  payload JSONB
);

DO $$
DECLARE
  v_user_email text := 'rodrigooidr@hotmail.com';  -- ajuste se precisar
  v_user_id uuid;
  v_org_id  uuid;

  has_created boolean;
  has_updated boolean;

  sql_ins text;
BEGIN
  -- 1) usuário
  SELECT id INTO v_user_id
  FROM public.users
  WHERE email = v_user_email
  LIMIT 1;
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Usuário % não encontrado', v_user_email;
  END IF;

  -- 2) org CresceJá (cria se não existir)
  SELECT id INTO v_org_id
  FROM public.orgs
  WHERE name = 'CresceJá'
  LIMIT 1;

  IF v_org_id IS NULL THEN
    -- Se sua tabela orgs não tiver created_at/updated_at, remova-os abaixo
    INSERT INTO public.orgs (id, name, created_at, updated_at)
    VALUES (uuid_generate_v4(), 'CresceJá', now(), now())
    RETURNING id INTO v_org_id;
  END IF;

  -- 3) vincular na org_users (sem coluna perms)
  IF NOT EXISTS (SELECT 1 FROM public.org_users WHERE org_id = v_org_id AND user_id = v_user_id) THEN
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name='org_users' AND column_name='created_at'
    ) INTO has_created;

    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name='org_users' AND column_name='updated_at'
    ) INTO has_updated;

    sql_ins := 'INSERT INTO public.org_users (org_id, user_id, role';
    IF has_created THEN sql_ins := sql_ins || ', created_at'; END IF;
    IF has_updated THEN sql_ins := sql_ins || ', updated_at'; END IF;
    sql_ins := sql_ins || ') VALUES ($1, $2, ''OrgOwner''';
    IF has_created THEN sql_ins := sql_ins || ', now()'; END IF;
    IF has_updated THEN sql_ins := sql_ins || ', now()'; END IF;
    sql_ins := sql_ins || ')';

    EXECUTE sql_ins USING v_org_id, v_user_id;
  END IF;

  RAISE NOTICE 'OK: usuário % vinculado à org %', v_user_id, v_org_id;
END
$$;

CREATE INDEX IF NOT EXISTS idx_conversations_org_contact ON conversations(org_id, contact_id);
CREATE INDEX IF NOT EXISTS idx_conversations_channel_id   ON conversations(channel_id);
CREATE INDEX IF NOT EXISTS idx_contacts_phone             ON contacts(phone_e164);

ALTER TABLE public.conversations
  ADD COLUMN IF NOT EXISTS ai_enabled boolean NOT NULL DEFAULT true;
  
  ALTER TABLE public.conversations
  ADD COLUMN IF NOT EXISTS ai_enabled boolean NOT NULL DEFAULT true;
  
  CREATE INDEX IF NOT EXISTS idx_conversations_org_last ON public.conversations(org_id, last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversations_org_contact ON public.conversations(org_id, contact_id);
CREATE INDEX IF NOT EXISTS idx_messages_conv_created ON public.messages(conversation_id, created_at DESC);

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

DO $$
DECLARE
  v_org_id  uuid := '00000000-0000-0000-0000-000000000001'; -- troque se quiser
  v_phone   text := '+5511999990001';
  v_ch_id   uuid;
  v_ct_id   uuid;
  v_conv_id uuid;
  v_wa_type text;
BEGIN
  -- pega um tipo de WhatsApp aceito pelo seu CHECK
  SELECT CASE
           WHEN EXISTS (
             SELECT 1 FROM pg_constraint
              WHERE conrelid='public.channels'::regclass
                AND conname='channels_type_check'
                AND pg_get_constraintdef(oid) ILIKE '%''whatsapp_cloud''%'
           ) THEN 'whatsapp_cloud'
           WHEN EXISTS (
             SELECT 1 FROM pg_constraint
              WHERE conrelid='public.channels'::regclass
                AND conname='channels_type_check'
                AND pg_get_constraintdef(oid) ILIKE '%''whatsapp_baileys''%'
           ) THEN 'whatsapp_baileys'
           ELSE 'whatsapp_cloud'
         END INTO v_wa_type;

  -- canal
  SELECT id INTO v_ch_id
  FROM public.channels
  WHERE org_id = v_org_id AND type = v_wa_type AND name = 'WhatsApp Principal'
  LIMIT 1;

  IF v_ch_id IS NULL THEN
    INSERT INTO public.channels (id, org_id, type, name, config, secrets, created_at)
    VALUES (uuid_generate_v4(), v_org_id, v_wa_type, 'WhatsApp Principal', '{}'::jsonb, '{}'::jsonb, now())
    RETURNING id INTO v_ch_id;
  END IF;

  -- contato
  SELECT id INTO v_ct_id
  FROM public.contacts
  WHERE org_id = v_org_id AND phone_e164 = v_phone
  LIMIT 1;

  IF v_ct_id IS NULL THEN
    INSERT INTO public.contacts (id, org_id, name, phone_e164, created_at, updated_at, tags)
    VALUES (uuid_generate_v4(), v_org_id, 'Cliente Teste', v_phone, now(), now(), ARRAY['vip'])
    RETURNING id INTO v_ct_id;
  END IF;

  -- conversa
  SELECT id INTO v_conv_id
  FROM public.conversations
  WHERE org_id = v_org_id AND contact_id = v_ct_id AND channel_id = v_ch_id
  LIMIT 1;

  IF v_conv_id IS NULL THEN
    INSERT INTO public.conversations (id, org_id, contact_id, channel_id, status, unread_count, last_message_at, created_at, updated_at)
    VALUES (uuid_generate_v4(), v_org_id, v_ct_id, v_ch_id, 'pending', 0, now(), now(), now())
    RETURNING id INTO v_conv_id;
  END IF;

  -- insere mensagens somente se ainda não houver
  IF NOT EXISTS (SELECT 1 FROM public.messages WHERE org_id=v_org_id AND conversation_id=v_conv_id) THEN
    -- detecta colunas opcionais
    PERFORM 1
    FROM information_schema.columns
    WHERE table_schema='public' AND table_name='messages' AND column_name='sender';

    IF FOUND THEN
      -- sua base exige sender e (provavelmente) direction; use os valores aceitos pelo CHECK
      INSERT INTO public.messages
        (id, org_id, conversation_id, sender, direction, "from", provider, type, text, status, created_at, updated_at)
      VALUES
        -- cliente → inbound
        (uuid_generate_v4(), v_org_id, v_conv_id, 'contact', 'inbound',  'customer', 'wa', 'text', 'Olá! Quero saber sobre o serviço.', 'sent', now(), now()),
        -- agente → outbound
        (uuid_generate_v4(), v_org_id, v_conv_id, 'agent',   'outbound', 'agent',    'wa', 'text', 'Oi! Posso ajudar, qual a sua dúvida?', 'sent', now(), now());
    ELSE
      -- versão simples (sem sender/direction)
      INSERT INTO public.messages
        (id, org_id, conversation_id, "from", provider, type, text, status, created_at, updated_at)
      VALUES
        (uuid_generate_v4(), v_org_id, v_conv_id, 'customer', 'wa', 'text', 'Olá! Quero saber sobre o serviço.', 'sent', now(), now()),
        (uuid_generate_v4(), v_org_id, v_conv_id, 'agent',    'wa', 'text', 'Oi! Posso ajudar, qual a sua dúvida?', 'sent', now(), now());
    END IF;
  END IF;

  UPDATE public.conversations
     SET last_message_at = now(), updated_at = now()
   WHERE id = v_conv_id;
END
$$;


ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS notes     text;
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS birthdate date;
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS tags      text[] DEFAULT '{}';

CREATE TABLE IF NOT EXISTS public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  channel text NOT NULL DEFAULT 'whatsapp',
  status  text NOT NULL DEFAULT 'open',
  ai_enabled boolean NOT NULL DEFAULT false,
  unread_count int NOT NULL DEFAULT 0,
  last_message_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_conversations_org ON public.conversations(org_id);
CREATE INDEX IF NOT EXISTS idx_conversations_last ON public.conversations(org_id, last_message_at DESC);

-- messages
CREATE TABLE IF NOT EXISTS public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  author_id text,
  direction text NOT NULL, -- 'in' | 'out'
  text text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON public.messages(org_id, conversation_id, created_at);

-- índice para busca por nome
CREATE INDEX IF NOT EXISTS idx_clients_org_name ON public.clients(org_id, lower(name));

-- ==== CLIENTS: colunas opcionais usadas pelo app ====
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS notes     text;
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS birthdate date;
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS tags      text[] DEFAULT '{}';

-- índice de busca por nome
CREATE INDEX IF NOT EXISTS idx_clients_org_name ON public.clients(org_id, lower(name));

-- ==== CONVERSATIONS: alinhar ao modelo atual ====
-- cria tabela se não existir
CREATE TABLE IF NOT EXISTS public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- acrescenta colunas que podem faltar
ALTER TABLE public.conversations
  ADD COLUMN IF NOT EXISTS client_id uuid,
  ADD COLUMN IF NOT EXISTS channel text NOT NULL DEFAULT 'whatsapp',
  ADD COLUMN IF NOT EXISTS status  text NOT NULL DEFAULT 'open',
  ADD COLUMN IF NOT EXISTS ai_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS unread_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_message_at timestamptz;

-- FK para clients (se ainda não existir)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'fk_conversations_client'
  ) THEN
    ALTER TABLE public.conversations
      ADD CONSTRAINT fk_conversations_client
      FOREIGN KEY (client_id)
      REFERENCES public.clients(id)
      ON DELETE CASCADE;
  END IF;
END $$;

-- índices úteis
CREATE INDEX IF NOT EXISTS idx_conversations_org       ON public.conversations(org_id);
CREATE INDEX IF NOT EXISTS idx_conversations_last_msg  ON public.conversations(org_id, last_message_at DESC);

-- ==== MESSAGES: cria/ajusta ====
CREATE TABLE IF NOT EXISTS public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL,
  conversation_id uuid NOT NULL,
  author_id text,
  direction text NOT NULL, -- 'in' | 'out'
  text text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- FK para conversations (se ainda não existir)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'fk_messages_conversation'
  ) THEN
    ALTER TABLE public.messages
      ADD CONSTRAINT fk_messages_conversation
      FOREIGN KEY (conversation_id)
      REFERENCES public.conversations(id)
      ON DELETE CASCADE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_messages_conv ON public.messages(org_id, conversation_id, created_at);

-- ===== Extensions =====
CREATE EXTENSION IF NOT EXISTS pgcrypto;  -- gen_random_uuid()

-- ===== Schema utilitário para GUC helpers =====
CREATE SCHEMA IF NOT EXISTS app;

-- Retorna current_setting('app.user_id', true)::uuid com NULL seguro
CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT CASE
    WHEN current_setting('app.user_id', true) IS NULL
         OR current_setting('app.user_id', true) = '' THEN NULL
    ELSE current_setting('app.user_id', true)::uuid
  END;
$$;

CREATE OR REPLACE FUNCTION app.current_org_id() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT CASE
    WHEN current_setting('app.org_id', true) IS NULL
         OR current_setting('app.org_id', true) = '' THEN NULL
    ELSE current_setting('app.org_id', true)::uuid
  END;
$$;

CREATE OR REPLACE FUNCTION app.current_role() RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT COALESCE(NULLIF(current_setting('app.role', true), ''), 'user');
$$;

-- ===== Tabelas =====
CREATE TABLE IF NOT EXISTS organizations (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  slug       text UNIQUE,
  status     text NOT NULL DEFAULT 'active', -- active | suspended | archived
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS org_memberships (
  org_id uuid NOT NULL,
  user_id uuid NOT NULL,
  role text NOT NULL DEFAULT 'Viewer',  -- OrgOwner | OrgAdmin | Manager | Agent | Viewer
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, user_id),
  CONSTRAINT org_memberships_org_fk
    FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);

-- Adiciona FK para users(id) se a tabela existir
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'users'
  ) THEN
    PERFORM 1
    FROM pg_constraint c
    WHERE c.conname = 'org_memberships_user_fk';

    IF NOT FOUND THEN
      ALTER TABLE org_memberships
        ADD CONSTRAINT org_memberships_user_fk
        FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
    END IF;
  END IF;
END$$;

-- ===== Índices =====
CREATE INDEX IF NOT EXISTS idx_orgs_name ON organizations (name);
CREATE INDEX IF NOT EXISTS idx_memberships_user ON org_memberships (user_id);
CREATE INDEX IF NOT EXISTS idx_memberships_org ON org_memberships (org_id);

-- ===== RLS =====
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_memberships ENABLE ROW LEVEL SECURITY;

-- Policies: membros veem suas orgs
DROP POLICY IF EXISTS orgs_member_sel ON organizations;
CREATE POLICY orgs_member_sel ON organizations
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM org_memberships m
    WHERE m.org_id = organizations.id
      AND app.current_user_id() IS NOT NULL
      AND m.user_id = app.current_user_id()
  )
);

-- Policies: SuperAdmin/Support veem todas
DROP POLICY IF EXISTS orgs_super_sel ON organizations;
CREATE POLICY orgs_super_sel ON organizations
FOR SELECT
USING ( app.current_role() IN ('SuperAdmin','Support') );

-- Memberships: o próprio usuário enxerga seus vínculos; superusers veem tudo
DROP POLICY IF EXISTS mem_self_sel ON org_memberships;
CREATE POLICY mem_self_sel ON org_memberships
FOR SELECT
USING (
  app.current_role() IN ('SuperAdmin','Support')
  OR (app.current_user_id() IS NOT NULL AND user_id = app.current_user_id())
);

-- (Opcional) você pode criar policies de INSERT/UPDATE/DELETE depois

-- ===== Seed da organização padrão (id já usado no seu token) =====
INSERT INTO organizations (id, name, slug, status)
VALUES ('00000000-0000-0000-0000-000000000001', 'Default Org', 'default', 'active')
ON CONFLICT (id) DO NOTHING;

-- ===== Seed do membership do Rodrigo como OrgOwner (se o usuário existir) =====
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- ajuste o email se necessário
  SELECT id INTO v_user_id FROM public.users WHERE email = 'rodrigooidr@hotmail.com' LIMIT 1;

  IF v_user_id IS NOT NULL THEN
    INSERT INTO org_memberships (org_id, user_id, role)
    VALUES ('00000000-0000-0000-0000-000000000001', v_user_id, 'OrgOwner')
    ON CONFLICT (org_id, user_id) DO UPDATE SET role = EXCLUDED.role;
  END IF;
END$$;

-- ===== Gatilho simples de updated_at =====
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_proc WHERE proname = 'touch_updated_at'
  ) THEN
    CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS trigger AS $f$
    BEGIN
      NEW.updated_at := now();
      RETURN NEW;
    END;
    $f$ LANGUAGE plpgsql;
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_trigger
    WHERE tgname = 'trg_orgs_touch_updated_at'
  ) THEN
    CREATE TRIGGER trg_orgs_touch_updated_at
    BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE PROCEDURE touch_updated_at();
  END IF;
END$$;

CREATE UNIQUE INDEX IF NOT EXISTS ux_plan_features_plan_code
  ON plan_features(plan_id, feature_code);
  
  CREATE TABLE IF NOT EXISTS google_calendar_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  google_user_id text NOT NULL,
  email text,
  display_name text,
  is_active boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, google_user_id)
);

CREATE INDEX IF NOT EXISTS ix_gcal_accounts_org ON google_calendar_accounts(org_id);

INSERT INTO feature_defs (code, label, type, unit, category, sort_order, is_public, show_as_tick)
VALUES
  ('whatsapp_numbers', 'WhatsApp – Quantidade de números', 'number', NULL, 'whatsapp', 10, true, false),
  ('google_calendar_accounts', 'Google Calendar – Contas conectadas', 'number', NULL, 'google', 20, true, false),
  ('whatsapp_mode_baileys', 'WhatsApp – Baileys habilitado', 'boolean', NULL, 'whatsapp', 30, false, false)
ON CONFLICT (code) DO NOTHING;

CREATE TABLE IF NOT EXISTS google_oauth_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES google_calendar_accounts(id) ON DELETE CASCADE,
  access_token text NOT NULL,
  refresh_token text,
  expiry timestamptz,
  scopes text[],
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS facebook_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  page_id text NOT NULL,
  name text,
  category text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, page_id)
);

CREATE TABLE IF NOT EXISTS facebook_oauth_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES facebook_pages(id) ON DELETE CASCADE,
  access_token text NOT NULL,   -- criptografado com AES-256-GCM (mesmo util já usado)
  enc_ver int2 NOT NULL DEFAULT 1,
  scopes text[],
  expiry timestamptz,           -- se houver; page tokens podem ser long-lived
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (page_id)
);

CREATE TABLE IF NOT EXISTS instagram_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  ig_user_id text NOT NULL,
  username text,
  name text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, ig_user_id)
);

CREATE INDEX IF NOT EXISTS ix_ig_accounts_org ON instagram_accounts(org_id);

CREATE TABLE IF NOT EXISTS instagram_oauth_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  access_token text NOT NULL,         -- cifrado (AES-256-GCM)
  enc_ver int2 NOT NULL DEFAULT 1,
  scopes text[],
  expiry timestamptz,                 -- quando aplicável
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (account_id)
);

INSERT INTO feature_defs (code, label, type, unit, category, sort_order, is_public)
VALUES ('instagram_publish_daily_quota','Instagram – Publicações por dia','number','count','social',32,true)
ON CONFLICT (code) DO UPDATE SET label=EXCLUDED.label, type=EXCLUDED.type, unit=EXCLUDED.unit, category=EXCLUDED.category, sort_order=EXCLUDED.sort_order, is_public=EXCLUDED.is_public;

-- Exemplo de seed de quotas (ajuste conforme seus planos)
WITH data(plan_name, feature_code, val) AS (
  VALUES
  ('Free','instagram_publish_daily_quota','{"enabled": true, "limit": 1}'),
  ('Starter','instagram_publish_daily_quota','{"enabled": true, "limit": 5}'),
  ('Pro','instagram_publish_daily_quota','{"enabled": true, "limit": 20}')
)
INSERT INTO plan_features (plan_id, feature_code, value)
SELECT p.id, d.feature_code, d.val::jsonb
FROM data d JOIN plans p ON p.name ILIKE d.plan_name
ON CONFLICT (plan_id, feature_code) DO UPDATE SET value = EXCLUDED.value, updated_at=now();

CREATE TABLE IF NOT EXISTS instagram_publish_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('image','carousel','video')),
  caption text,
  media jsonb NOT NULL,               -- [{url:"..."},{...}] ou {url:"..."}
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','creating','ready','publishing','done','failed','canceled')),
  error text,
  scheduled_at timestamptz,           -- null = publicar agora
  creation_id text,                   -- id do container
  published_media_id text,            -- id do post publicado
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_ig_jobs_org_sch ON instagram_publish_jobs(org_id, scheduled_at);
CREATE INDEX IF NOT EXISTS ix_ig_jobs_status ON instagram_publish_jobs(status);

ALTER TABLE instagram_publish_jobs
  ADD COLUMN IF NOT EXISTS client_dedupe_key text;

CREATE UNIQUE INDEX IF NOT EXISTS ux_ig_jobs_dedupe
  ON instagram_publish_jobs(org_id, account_id, client_dedupe_key)
  WHERE status IN ('pending','creating','publishing');


UPDATE instagram_publish_jobs
   SET status='creating', updated_at=now()
 WHERE id IN (
   SELECT id FROM instagram_publish_jobs
    WHERE status='pending' AND scheduled_at <= now()
    ORDER BY scheduled_at ASC
    FOR UPDATE SKIP LOCKED
    LIMIT 20
 )
 RETURNING *;

CREATE TABLE IF NOT EXISTS facebook_publish_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  page_id uuid NOT NULL REFERENCES facebook_pages(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('text','link','image','multi_image','video')),
  message text,                      -- legenda/texto
  link text,                         -- opcional p/ posts de link
  media jsonb,                       -- image: {url}, multi: [{url},{...}], video: {url}
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','creating','ready','publishing','done','failed','canceled')),
  error text,
  scheduled_at timestamptz,          -- null = publicar agora
  published_post_id text,            -- id do post publicado
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  client_dedupe_key text             -- para idempotência
);

CREATE INDEX IF NOT EXISTS ix_fb_jobs_org_sched ON facebook_publish_jobs(org_id, scheduled_at);
CREATE INDEX IF NOT EXISTS ix_fb_jobs_status ON facebook_publish_jobs(status);

-- idempotência (mesma ideia do Instagram)
CREATE UNIQUE INDEX IF NOT EXISTS ux_fb_jobs_dedupe
  ON facebook_publish_jobs(org_id, page_id, client_dedupe_key)
  WHERE status IN ('pending','creating','publishing');

INSERT INTO feature_defs (code, label, type, unit, category, sort_order, is_public)
VALUES ('facebook_publish_daily_quota','Facebook – Publicações por dia','number','count','social',33,true)
ON CONFLICT (code) DO UPDATE SET label=EXCLUDED.label, type=EXCLUDED.type, unit=EXCLUDED.unit,
  category=EXCLUDED.category, sort_order=EXCLUDED.sort_order, is_public=EXCLUDED.is_public;

-- seeds exemplo (ajuste aos seus planos)
WITH data(plan_name, feature_code, val) AS (
  VALUES
  ('Free','facebook_publish_daily_quota','{"enabled": true, "limit": 1}'),
  ('Starter','facebook_publish_daily_quota','{"enabled": true, "limit": 5}'),
  ('Pro','facebook_publish_daily_quota','{"enabled": true, "limit": 20}')
)
INSERT INTO plan_features (plan_id, feature_code, value)
SELECT p.id, d.feature_code, d.val::jsonb
FROM data d JOIN plans p ON p.name ILIKE d.plan_name
ON CONFLICT (plan_id, feature_code) DO UPDATE SET value=EXCLUDED.value, updated_at=now();

UPDATE facebook_publish_jobs
   SET status='creating', updated_at=now()
 WHERE id IN (
   SELECT id FROM facebook_publish_jobs
   WHERE status='pending' AND scheduled_at <= now()
   ORDER BY scheduled_at ASC
   FOR UPDATE SKIP LOCKED
   LIMIT 20
 )
 RETURNING *;

CREATE TABLE IF NOT EXISTS content_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  month_ref date NOT NULL,                 -- usar primeiro dia do mês (ex.: 2025-10-01)
  default_targets jsonb NOT NULL DEFAULT '{}'::jsonb, -- ex: {"ig":true,"fb":false}
  strategy_json jsonb,                     -- persona, tom, metas, etc.
  created_by uuid,                         -- user_id
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_campaigns_org_month ON content_campaigns(org_id, month_ref);

CREATE TYPE suggestion_status AS ENUM ('suggested','approved','scheduled','published','rejected');

CREATE TABLE IF NOT EXISTS content_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES content_campaigns(id) ON DELETE CASCADE,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  date date NOT NULL,
  time time with time zone,                -- horário sugerido
  channel_targets jsonb NOT NULL DEFAULT '{}'::jsonb, -- {"ig":true,"fb":false}
  status suggestion_status NOT NULL DEFAULT 'suggested',
  copy_json jsonb,                         -- {headline, caption, hashtags[], cta, variants[]}
  asset_refs jsonb,                        -- [{asset_id, url, type}] (opcional)
  ai_prompt_json jsonb,                    -- prompt/params usados
  reasoning_json jsonb,                    -- opcional para auditoria
  approved_by uuid,                        -- user_id
  approved_at timestamptz,
  published_at timestamptz,                -- quando TODOS os destinos forem publicados
  jobs_map jsonb DEFAULT '{}'::jsonb,      -- {"ig": "<job_id>", "fb":"<job_id>"}
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_suggestions_campaign ON content_suggestions(campaign_id);
CREATE INDEX IF NOT EXISTS ix_suggestions_org_date ON content_suggestions(org_id, date);


CREATE TYPE suggestion_status AS ENUM ('suggested','approved','scheduled','published','rejected');

CREATE TABLE IF NOT EXISTS content_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES content_campaigns(id) ON DELETE CASCADE,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  date date NOT NULL,
  time time with time zone,                -- horário sugerido
  channel_targets jsonb NOT NULL DEFAULT '{}'::jsonb, -- {"ig":true,"fb":false}
  status suggestion_status NOT NULL DEFAULT 'suggested',
  copy_json jsonb,                         -- {headline, caption, hashtags[], cta, variants[]}
  asset_refs jsonb,                        -- [{asset_id, url, type}] (opcional)
  ai_prompt_json jsonb,                    -- prompt/params usados
  reasoning_json jsonb,                    -- opcional para auditoria
  approved_by uuid,                        -- user_id
  approved_at timestamptz,
  published_at timestamptz,                -- quando TODOS os destinos forem publicados
  jobs_map jsonb DEFAULT '{}'::jsonb,      -- {"ig": "<job_id>", "fb":"<job_id>"}
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_suggestions_campaign ON content_suggestions(campaign_id);

CREATE TABLE IF NOT EXISTS content_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  url text NOT NULL,                -- URL assinada (S3/MinIO) pós-upload
  mime text NOT NULL,
  width int,
  height int,
  meta_json jsonb,                  -- {palette, brand, license, ...}
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_assets_org ON content_assets(org_id);



-- Instagram
SELECT date_trunc('day', schedule_at AT TIME ZONE 'America/Sao_Paulo')::date AS d,
       COUNT(*) AS ig_jobs
FROM instagram_publish_jobs
WHERE org_id = $1
  AND status IN ('pending','creating','publishing','scheduled')
  AND schedule_at >= $2::date
  AND schedule_at <  ($2::date + INTERVAL '1 month')
GROUP BY 1;

-- Facebook
SELECT date_trunc('day', schedule_at AT TIME ZONE 'America/Sao_Paulo')::date AS d,
       COUNT(*) AS fb_jobs
FROM facebook_publish_jobs
WHERE org_id = $1
  AND status IN ('pending','creating','publishing','scheduled')
  AND schedule_at >= $2::date
  AND schedule_at <  ($2::date + INTERVAL '1 month')
GROUP BY 1;

BEGIN;

-- Tabela de papéis globais
CREATE TABLE IF NOT EXISTS public.user_global_roles (
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  role    text NOT NULL,
  PRIMARY KEY (user_id, role)
);

-- Constraint de transição (aceita legado + PascalCase)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conname='user_global_roles_role_check'
       AND conrelid='public.user_global_roles'::regclass
  ) THEN
    ALTER TABLE public.user_global_roles DROP CONSTRAINT user_global_roles_role_check;
  END IF;
END$$;

ALTER TABLE public.user_global_roles
  ADD CONSTRAINT user_global_roles_role_check
  CHECK (role IN (
    -- alvo (PascalCase)
    'Support','SuperAdmin','BillingAdmin',
    -- legados que migraremos
    'support','super_admin','billing_admin'
  ));

-- Migração de dados legado -> PascalCase
UPDATE public.user_global_roles
   SET role = CASE role
     WHEN 'support'       THEN 'Support'
     WHEN 'super_admin'   THEN 'SuperAdmin'
     WHEN 'billing_admin' THEN 'BillingAdmin'
     ELSE role
   END
 WHERE role IN ('support','super_admin','billing_admin');

-- Fecha a constraint somente para PascalCase
ALTER TABLE public.user_global_roles DROP CONSTRAINT user_global_roles_role_check;
ALTER TABLE public.user_global_roles
  ADD CONSTRAINT user_global_roles_role_check
  CHECK (role IN ('Support','SuperAdmin','BillingAdmin'));

CREATE INDEX IF NOT EXISTS idx_user_global_roles_role ON public.user_global_roles(role);

COMMIT;

BEGIN;

------------------------------------------------------------
-- 1) ORG MEMBERS: enum -> text, normalização e CHECK
------------------------------------------------------------

-- 1.1) converter enum org_role -> text mantendo dados
ALTER TABLE public.org_members
  ALTER COLUMN role DROP DEFAULT;

ALTER TABLE public.org_members
  ALTER COLUMN role TYPE text
  USING (role::text);

-- 1.2) normalizar snake_case -> PascalCase
UPDATE public.org_members
SET role = CASE role
  WHEN 'org_viewer' THEN 'OrgViewer'
  WHEN 'org_agent'  THEN 'OrgAgent'
  WHEN 'org_admin'  THEN 'OrgAdmin'
  WHEN 'org_owner'  THEN 'OrgOwner'
  ELSE role
END
WHERE role IN ('org_viewer','org_agent','org_admin','org_owner');

-- 1.3) recriar CHECK apenas com papéis da organização
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.org_members'::regclass
      AND conname  = 'org_members_role_check'
  ) THEN
    ALTER TABLE public.org_members DROP CONSTRAINT org_members_role_check;
  END IF;
END$$;

ALTER TABLE public.org_members
  ADD CONSTRAINT org_members_role_check
  CHECK (role IN ('OrgViewer','OrgAgent','OrgAdmin','OrgOwner'));

-- (opcional) default: escolha se quer algum
-- ALTER TABLE public.org_members ALTER COLUMN role SET DEFAULT 'OrgAgent';


------------------------------------------------------------
-- 2) ORG MEMBERSHIPS: corrigir default/valores e CHECK
------------------------------------------------------------

-- 2.1) normalizar valores legados
UPDATE public.org_memberships
SET role = CASE role
  WHEN 'org_viewer' THEN 'OrgViewer'
  WHEN 'org_agent'  THEN 'OrgAgent'
  WHEN 'org_admin'  THEN 'OrgAdmin'
  WHEN 'org_owner'  THEN 'OrgOwner'
  WHEN 'Viewer'     THEN 'OrgViewer'
  WHEN 'Agent'      THEN 'OrgAgent'
  WHEN 'Admin'      THEN 'OrgAdmin'
  WHEN 'Owner'      THEN 'OrgOwner'
  ELSE role
END
WHERE role IN ('org_viewer','org_agent','org_admin','org_owner',
               'Viewer','Agent','Admin','Owner');

-- 2.2) default coerente
ALTER TABLE public.org_memberships
  ALTER COLUMN role SET DEFAULT 'OrgViewer';

-- 2.3) CHECK apenas com papéis da organização
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.org_memberships'::regclass
      AND conname  = 'org_memberships_role_check'
  ) THEN
    ALTER TABLE public.org_memberships DROP CONSTRAINT org_memberships_role_check;
  END IF;
END$$;

ALTER TABLE public.org_memberships
  ADD CONSTRAINT org_memberships_role_check
  CHECK (role IN ('OrgViewer','OrgAgent','OrgAdmin','OrgOwner'));


------------------------------------------------------------
-- 3) ORG USERS: corrigir CHECK (somente papéis de org)
------------------------------------------------------------

-- Remover CHECK antiga que mistura globais
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.org_users'::regclass
      AND conname  = 'org_users_role_check'
  ) THEN
    ALTER TABLE public.org_users DROP CONSTRAINT org_users_role_check;
  END IF;
END$$;

-- Criar CHECK correta
ALTER TABLE public.org_users
  ADD CONSTRAINT org_users_role_check
  CHECK (role IN ('OrgViewer','OrgAgent','OrgAdmin','OrgOwner'));


------------------------------------------------------------
-- 4) USER GLOBAL ROLES: tirar BillingAdmin e normalizar
------------------------------------------------------------

-- Normalizar quaisquer legados para PascalCase (só por garantia)
UPDATE public.user_global_roles
SET role = CASE role
  WHEN 'support'     THEN 'Support'
  WHEN 'super_admin' THEN 'SuperAdmin'
  ELSE role
END
WHERE role IN ('support','super_admin');

-- Remover CHECK antiga (que incluía BillingAdmin)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.user_global_roles'::regclass
      AND conname  = 'user_global_roles_role_check'
  ) THEN
    ALTER TABLE public.user_global_roles DROP CONSTRAINT user_global_roles_role_check;
  END IF;
END$$;

-- CHECK final: apenas Support e SuperAdmin
ALTER TABLE public.user_global_roles
  ADD CONSTRAINT user_global_roles_role_check
  CHECK (role IN ('Support','SuperAdmin'));

COMMIT;

DROP TYPE public.org_role;
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE t.typname = 'org_role' AND n.nspname = 'public'
  ) THEN
    EXECUTE 'DROP TYPE public.org_role';
  END IF;
END$$;

-- Habilita UUID v4 via pgcrypto (gen_random_uuid)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Cria a tabela, se ainda não existir
CREATE TABLE IF NOT EXISTS public.messages (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id            uuid NOT NULL,
  conversation_id   uuid NOT NULL,

  channel           text NOT NULL,                 -- ex.: 'whatsapp' | 'instagram' | 'messenger' | 'webchat'
  direction         text NOT NULL,                 -- 'in' (recebida) | 'out' (enviada)

  external_message_id text,                        -- id do provedor (twilio/meta/etc.)
  sender_id         uuid,
  sender_name       text,
  sender_role       text,                          -- ex.: 'agent' | 'bot' | 'customer'

  content           text,                          -- corpo textual
  content_type      text DEFAULT 'text',           -- 'text' | 'image' | 'audio' | 'file' | ...
  attachments       jsonb NOT NULL DEFAULT '[]',   -- lista de anexos
  meta              jsonb NOT NULL DEFAULT '{}',   -- metadados diversos

  status            text NOT NULL DEFAULT 'queued',-- 'queued'|'sent'|'delivered'|'read'|'failed'|'received'
  error             text,                          -- mensagem de erro (se falhou)

  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  sent_at           timestamptz,
  delivered_at      timestamptz,
  read_at           timestamptz
);

-- Garante a constraint pedida (nome exato) sem quebrar se já existir
DO $$
BEGIN
  IF to_regclass('public.messages') IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1
        FROM pg_constraint
       WHERE conname = 'messages_direction_check'
         AND conrelid = to_regclass('public.messages')
    ) THEN
      ALTER TABLE public.messages
        ADD CONSTRAINT messages_direction_check
        CHECK (direction IN ('in','out'));
    END IF;
  END IF;
END$$;

-- (Opcional) valida status permitido
DO $$
BEGIN
  IF to_regclass('public.messages') IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1
        FROM pg_constraint
       WHERE conname = 'messages_status_check'
         AND conrelid = to_regclass('public.messages')
    ) THEN
      ALTER TABLE public.messages
        ADD CONSTRAINT messages_status_check
        CHECK (status IN ('queued','sent','delivered','read','failed','received'));
    END IF;
  END IF;
END$$;

-- Índices úteis (idempotentes)
CREATE INDEX IF NOT EXISTS idx_messages_org    ON public.messages (org_id);
CREATE INDEX IF NOT EXISTS idx_messages_conv   ON public.messages (conversation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_chan   ON public.messages (channel, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_status ON public.messages (status);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_meta_gin ON public.messages USING GIN (meta);
