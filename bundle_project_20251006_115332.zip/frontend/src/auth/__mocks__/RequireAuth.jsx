export default function RequireAuth({ children }) { return children; }
