export { default } from '../config/db.js';
export * from '../config/db.js';
