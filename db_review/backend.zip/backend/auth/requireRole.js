import { requireRole } from '../middleware/requireRole.js';

export default requireRole;
