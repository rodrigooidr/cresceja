// Apenas documentação viva: Jest do backend roda com ESM habilitado via script npm.
// Nada obrigatório aqui, mas espaço para futuros stubs globais.
