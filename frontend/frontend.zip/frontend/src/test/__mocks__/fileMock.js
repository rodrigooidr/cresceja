// retorna um stub simples para assets
module.exports = 'test-file-stub';
