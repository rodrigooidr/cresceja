export { default } from './organizations/AdminOrganizationsPage.jsx';
