describe('debug socket module', () => {
  test('prints require result', () => {
    // eslint-disable-next-line no-console
    console.log('socket module:', require('../../sockets/socket'));
  });
});
