import React from "react";

export default function MarketingPage() {
  return (
    <div className="p-6" data-testid="marketing-page">
      <h1 className="text-2xl font-semibold mb-4">Marketing</h1>
      <p className="text-gray-600">Recursos de marketing.</p>
    </div>
  );
}

