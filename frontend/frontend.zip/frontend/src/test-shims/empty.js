// frontend/src/test-shims/empty.js
module.exports = {};
