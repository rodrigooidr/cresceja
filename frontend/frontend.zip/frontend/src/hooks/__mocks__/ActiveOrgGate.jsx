export default function ActiveOrgGate({ children }) { return children; }
