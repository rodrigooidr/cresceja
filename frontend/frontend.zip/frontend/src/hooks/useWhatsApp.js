export default function useWhatsApp() {
  return { connected: true };
}
