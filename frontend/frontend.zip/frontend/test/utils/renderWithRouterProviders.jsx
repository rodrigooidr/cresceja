// Proxy simples para o helper novo (sem act legado)
export { renderApp as default, renderApp as renderWithRouterProviders } from "./renderApp.jsx";
