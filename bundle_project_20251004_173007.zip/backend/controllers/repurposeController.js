// controllers/repurposeController.js

export function repurpose(req, res) {
  return res.json({ ok: true });
}
