// controllers/iaController.js

export function health(req, res) {
  return res.json({ ok: true });
}
